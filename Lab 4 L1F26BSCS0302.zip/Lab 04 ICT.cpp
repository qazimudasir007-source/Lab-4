// Name: Qazi Mudasir Ahmed
// Roll No: L1F26BSCS0302

//------------------------ TASK 01 - Positive Number? (if Statement)------------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int number;
    cout << "Enter an integer: ";
    cin >> number;

    if (number > 0) {
        cout << "Positive number" << endl;
    }

    // Observation: For 0 and -4, nothing is printed after the prompt
    // because neither value is greater than zero.
    return 0;
}
*/


//----------------------- TASK 02 - Check the Discount (if Statement)-------------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int billAmount;
    cout << "Enter bill amount: ";
    cin >> billAmount;

    cout << "Bill amount: Rs. " << billAmount << endl;
    if (billAmount >= 5000) {
        cout << "You qualify for a discount." << endl;
    }

    // Observation: >= includes exactly Rs. 5000; > would exclude it.
    return 0;
}
*/


//------------------------------ TASK 03 - Even or Odd (if-else Statement)-----------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int number;
    cout << "Enter an integer: ";
    cin >> number;

    if (number % 2 == 0) {
        cout << "Even number" << endl;
    } else {
        cout << "Odd number" << endl;
    }

    // Observation: Zero is even because 0 % 2 is equal to 0.
    return 0;
}
*/

//---------------------- TASK 04 - Voting Eligibility (if-else Statement)-----------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int age;
    cout << "Enter your age: ";
    cin >> age;

    if (age >= 18) {
        cout << "Eligible to vote" << endl;
    } else {
        cout << "Not eligible to vote" << endl;
    }

    return 0;
}
*/


//-------------------------------- TASK 05 - Compare Two Numbers (if-else Statement)--------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int firstNumber, secondNumber;
    cout << "Enter two numbers: ";
    cin >> firstNumber >> secondNumber;

    if (firstNumber > secondNumber) {
        cout << "First number is greater" << endl;
    } else {
        cout << "First number is not greater" << endl;
    }

    // Observation: Equal numbers produce "First number is not greater"
    // because the > condition is false when both values are equal.
    return 0;
}
*/


//--------------------- TASK 06 - Marks and Grade (if-else-if Statement)-----------------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter marks (0-100): ";
    cin >> marks;

    if (marks >= 90) {
        cout << "Grade: A" << endl;
    } else if (marks >= 80) {
        cout << "Grade: B" << endl;
    } else if (marks >= 70) {
        cout << "Grade: C" << endl;
    } else if (marks >= 60) {
        cout << "Grade: D" << endl;
    } else {
        cout << "Grade: F" << endl;
    }

    // Observation: Check the highest marks range first, because the first
    // true if-else-if branch runs. Otherwise, 95 could be given a lower grade.
    // The lab states that marks are assumed to be in the range 0 to 100.
    return 0;
}
*/


//-------------------------- TASK 07 - Temperature Description (if-else-if Statement)-------------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int temperature;
    cout << "Enter temperature in Celsius: ";
    cin >> temperature;

    if (temperature < 10) {
        cout << "Weather: Cold" << endl;
    } else if (temperature < 25) {
        cout << "Weather: Pleasant" << endl;
    } else if (temperature < 35) {
        cout << "Weather: Warm" << endl;
    } else {
        cout << "Weather: Hot" << endl;
    }

    // Observation: For 18, the first check (18 < 10) is false,
    // and the next check (18 < 25) is the first true condition.
    return 0;
}
*/


//-------------------- TASK 08 - Debug the Conditions------------------------------

/*
#include <iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter marks: ";
    cin >> marks;

    if (marks >= 50) {
        cout << "Pass" << endl;
    } else {
        cout << "Fail" << endl;
    }

    // Correction: = assigns a value, while == compares for equality.
    // The correct condition here is >=, meaning greater than or equal to 50.
    return 0;
}
*/


//--------------------- TASK 09 - Electricity Usage Category (Flowchart to Program)-------------------

/*
#include <iostream>
using namespace std;

int main() {
    int units;
    cout << "Enter monthly units: ";
    cin >> units;

    if (units <= 100) {
        cout << "Usage category: Low usage" << endl;
    } else if (units <= 300) {
        cout << "Usage category: Medium usage" << endl;
    } else {
        cout << "Usage category: High usage" << endl;
    }

    return 0;
}
*/


//--------------------- TASK 10 - Scholarship Eligibility (Flowchart to Code)--------------------

/*
#include <iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter marks: ";
    cin >> marks;

    if (marks >= 85) {
        cout << "Scholarship awarded" << endl;
    } else {
        cout << "Scholarship not awarded" << endl;
    }

    return 0;
}
*/


//-------------- TASK 11 - Museum Ticket Price (if-else-if Statement)------------

/*
#include <iostream>
using namespace std;

int main() {
    int visitorAge;
    cout << "Enter visitor age: ";
    cin >> visitorAge;

    if (visitorAge < 0) {
        cout << "Invalid age" << endl;
    } else if (visitorAge < 5) {
        cout << "Free entry" << endl;
    } else if (visitorAge < 18) {
        cout << "Child/Student ticket: Rs. 200" << endl;
    } else if (visitorAge < 60) {
        cout << "Adult ticket: Rs. 500" << endl;
    } else {
        cout << "Senior ticket: Rs. 300" << endl;
    }

    // Observation: Checking negative ages first prevents them from being
    // classified as free entry. The remaining age ranges do not overlap.
    return 0;
}
*/
